
function onMouseEnter(event) {
	event.currentTarget.className = "hovered";
}

function onMouseLeave(event) {
	event.currentTarget.className = "unhovered";
}
